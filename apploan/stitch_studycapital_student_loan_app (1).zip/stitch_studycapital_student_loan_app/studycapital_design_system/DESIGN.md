---
name: StudyCapital Design System
colors:
  surface: '#071325'
  surface-dim: '#071325'
  surface-bright: '#2e394d'
  surface-container-lowest: '#030e20'
  surface-container-low: '#101c2e'
  surface-container: '#142032'
  surface-container-high: '#1f2a3d'
  surface-container-highest: '#2a3548'
  on-surface: '#d7e3fc'
  on-surface-variant: '#d8c3ad'
  inverse-surface: '#d7e3fc'
  inverse-on-surface: '#253144'
  outline: '#a08e7a'
  outline-variant: '#534434'
  surface-tint: '#ffb95f'
  primary: '#ffc174'
  on-primary: '#472a00'
  primary-container: '#f59e0b'
  on-primary-container: '#613b00'
  inverse-primary: '#855300'
  secondary: '#b5c4ff'
  on-secondary: '#00297a'
  secondary-container: '#044dd3'
  on-secondary-container: '#c3cfff'
  tertiary: '#bdcee7'
  on-tertiary: '#213145'
  tertiary-container: '#a2b2cb'
  on-tertiary-container: '#35455a'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#ffddb8'
  primary-fixed-dim: '#ffb95f'
  on-primary-fixed: '#2a1700'
  on-primary-fixed-variant: '#653e00'
  secondary-fixed: '#dbe1ff'
  secondary-fixed-dim: '#b5c4ff'
  on-secondary-fixed: '#00174d'
  on-secondary-fixed-variant: '#003dab'
  tertiary-fixed: '#d3e4fe'
  tertiary-fixed-dim: '#b7c8e1'
  on-tertiary-fixed: '#0b1c30'
  on-tertiary-fixed-variant: '#38485d'
  background: '#071325'
  on-background: '#d7e3fc'
  surface-variant: '#2a3548'
typography:
  headline-lg:
    fontFamily: Newsreader
    fontSize: 40px
    fontWeight: '600'
    lineHeight: '1.2'
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Newsreader
    fontSize: 32px
    fontWeight: '500'
    lineHeight: '1.3'
  headline-sm:
    fontFamily: Manrope
    fontSize: 24px
    fontWeight: '700'
    lineHeight: '1.4'
  body-lg:
    fontFamily: Manrope
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.6'
  body-md:
    fontFamily: Manrope
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.6'
  label-md:
    fontFamily: Manrope
    fontSize: 14px
    fontWeight: '600'
    lineHeight: '1.2'
    letterSpacing: 0.05em
  label-sm:
    fontFamily: Manrope
    fontSize: 12px
    fontWeight: '500'
    lineHeight: '1.2'
    letterSpacing: 0.03em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 8px
  container-margin: 24px
  gutter: 16px
  stack-sm: 8px
  stack-md: 16px
  stack-lg: 32px
  section-padding: 48px
---

## Brand & Style

This design system is engineered to project an aura of fiscal intelligence, stability, and premium exclusivity. Targeted at high-net-worth individuals and serious students of the market, the visual language balances the cold, analytical nature of finance with the warm, high-energy drive of capital growth.

The aesthetic follows a **Corporate Modern** approach with subtle **Glassmorphic** accents. It prioritizes clarity and high-density information without sacrificing the "premium" feel. The interface feels like a secure digital vault: dark, layered, and meticulously organized. Surfaces are not flat; they utilize depth to guide the user’s eye toward growth metrics and critical action points.

## Colors

The palette is rooted in a "Deep Sea" philosophy. The foundation is built upon **#0A1628**, a deep navy that provides more soul and depth than pure black. This is complemented by a Slate tertiary scale to handle borders and secondary text.

**Primary Action:** The Vibrant Orange (**#F59E0B**) is reserved exclusively for "Growth" actions—investing, profit indicators, and primary calls to action. Its high contrast against the navy background ensures immediate cognitive recognition.

**Emphasis:** The Deep Blue (**#1A56DB**) is utilized for focus states, informational icons, and trust-building elements, maintaining a connection to traditional banking reliability.

**Functional Neutrals:**
- **Surface:** #111E2F (slightly lighter navy for cards)
- **Border:** #1E293B (slate for subtle separation)
- **Success/Error:** Inherited semantic greens and reds, but desaturated to fit the dark environment.

## Typography

This design system employs a dual-font strategy to balance authority with modern utility. 

**Newsreader** is the editorial voice. It is used for large headings, portfolio summaries, and section titles to evoke the prestige of financial journalism. Its serif structure provides the "authoritative" weight requested.

**Manrope** is the functional workhorse. It is used for all UI elements, data grids, and body copy. Its geometric clarity ensures that complex financial figures remain legible at small sizes. 

All labels use a slightly increased letter-spacing and uppercase styling where appropriate to create a sense of professional hierarchy.

## Layout & Spacing

The system uses an **8px linear scale** to ensure mathematical harmony across all components. The layout follows a **12-column fluid grid** for desktop and a single-column fluid layout with **24px side margins** for mobile.

Information density is "Moderate-High." In financial contexts, users need to see data, so vertical spacing is tightened in data tables (8px gutters) while being more generous in marketing or "Educational" sections (32px+ stacks). Whitespace is treated as a premium tool to isolate critical numbers, such as "Total Balance" or "Profit/Loss."

## Elevation & Depth

Depth is communicated through **Tonal Layering** and **Subtle Blurs** rather than heavy shadows. 

1.  **Level 0 (Base):** #0A1628 (The deep background).
2.  **Level 1 (Cards/Surfaces):** #111E2F. Used for the primary container of content.
3.  **Level 2 (Overlays/Modals):** #1A2638 with a 20px backdrop blur and a 1px inner border (#FFFFFF10).
4.  **Interactive Focus:** Elements that are active or hovered receive a subtle outer glow using the Primary Orange or Secondary Blue at 10% opacity, creating a "pulsing" light effect that feels high-tech and responsive.

Shadows, when used, are ultra-diffused: `0px 10px 30px rgba(0, 0, 0, 0.5)`.

## Shapes

The shape language is "Sophisticated Geometric." We utilize a **roundedness of 0.5rem (8px)** for standard components like buttons and cards. This strikes a balance between the aggressive sharpness of traditional finance (square) and the overly playful nature of consumer apps (pill).

- **Standard Radius:** 8px (Buttons, Inputs, Small Cards).
- **Large Radius:** 16px (Main dashboard containers, Modals).
- **Utility Radius:** 4px (Chips, small indicators).

Interactive elements like "Trade" buttons may occasionally use a pill-shape to distinguish them from standard form buttons, but the default remains 8px.

## Components

**Buttons:**
- **Primary:** Solid #F59E0B with #0A1628 text. Bold weight.
- **Secondary:** Outlined with #1A56DB, 1.5px border thickness.
- **Ghost:** No background, Slate-400 text, becomes White on hover.

**Inputs:**
Fields use a dark fill (#0D1B2D) with a subtle bottom border. Upon focus, the border transitions to Primary Orange with a soft glow. Labels sit above the field in `label-sm` Manrope.

**Cards:**
Cards are the primary unit of the layout. They feature a #1E293B border (1px) and use the Level 1 surface color. For premium features, cards may utilize a subtle linear gradient from #111E2F to #1A2638.

**Data Display:**
- **Positive Metrics:** Use a desaturated mint green.
- **Negative Metrics:** Use a soft coral red.
- **Charts:** Use a monochromatic blue gradient with the Orange primary color as the "current value" pointer.

**Chips:**
Small, low-profile tags used for categories (e.g., "Equity," "Fixed Income") with a Slate-800 background and Slate-200 text.