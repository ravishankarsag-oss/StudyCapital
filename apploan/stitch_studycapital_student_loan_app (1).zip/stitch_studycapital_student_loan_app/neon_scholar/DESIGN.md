---
name: Neon Scholar
colors:
  surface: '#07122a'
  surface-dim: '#07122a'
  surface-bright: '#2f3952'
  surface-container-lowest: '#030d25'
  surface-container-low: '#101b33'
  surface-container: '#151f37'
  surface-container-high: '#1f2942'
  surface-container-highest: '#2a344e'
  on-surface: '#d9e2ff'
  on-surface-variant: '#e2bfb0'
  inverse-surface: '#d9e2ff'
  inverse-on-surface: '#263049'
  outline: '#a98a7d'
  outline-variant: '#5a4136'
  surface-tint: '#ffb693'
  primary: '#ffb693'
  on-primary: '#561f00'
  primary-container: '#ff6b00'
  on-primary-container: '#572000'
  inverse-primary: '#a04100'
  secondary: '#b9c7e4'
  on-secondary: '#233148'
  secondary-container: '#3c4962'
  on-secondary-container: '#abb9d6'
  tertiary: '#b6c6ed'
  on-tertiary: '#20304f'
  tertiary-container: '#8999bd'
  on-tertiary-container: '#213150'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#ffdbcc'
  primary-fixed-dim: '#ffb693'
  on-primary-fixed: '#351000'
  on-primary-fixed-variant: '#7a3000'
  secondary-fixed: '#d6e3ff'
  secondary-fixed-dim: '#b9c7e4'
  on-secondary-fixed: '#0d1c32'
  on-secondary-fixed-variant: '#39475f'
  tertiary-fixed: '#d8e2ff'
  tertiary-fixed-dim: '#b6c6ed'
  on-tertiary-fixed: '#091b39'
  on-tertiary-fixed-variant: '#374767'
  background: '#07122a'
  on-background: '#d9e2ff'
  surface-variant: '#2a344e'
typography:
  display-lg:
    fontFamily: Manrope
    fontSize: 48px
    fontWeight: '800'
    lineHeight: 56px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Manrope
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
  body-base:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-caps:
    fontFamily: Space Grotesk
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.1em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  unit: 4px
  container-max: 1280px
  gutter: 24px
  margin-mobile: 16px
  margin-desktop: 48px
---

## Brand & Style
The brand personality for this design system is authoritative yet high-energy, blending the institutional trust of financial education with the kinetic energy of modern trading platforms. It targets ambitious learners who value precision and "alpha." 

The design style is **High-Contrast Modern with Glassmorphism**. By utilizing a deep navy foundation paired with a hyper-saturated neon orange, the UI creates an immediate visual hierarchy that directs the user's eye to conversion points and critical data insights. Surfaces feel "layered" rather than flat, utilizing subtle transparency to maintain a premium, sophisticated atmosphere.

## Colors
The palette is built on a "Deep Sea" foundation to ensure a premium dark mode experience. The **Primary Color (#FF6B00)** is a high-vibrancy neon orange used exclusively for interactive elements and critical highlights. 

- **Primary:** Neon Orange (#FF6B00) for CTAs, active states, and progress indicators.
- **Surface Deep:** Navy (#0A192F) for the global background.
- **Surface Elevated:** Slate Navy (#112240) for cards and modals.
- **Accents:** A subtle "Electric Blue" (#64FFDA) can be used sparingly for secondary data points to complement the orange.
- **Text:** High-purity white (#CCD6F6) for headings and muted slate (#8892B0) for secondary body text.

## Typography
This design system employs a three-font strategy to balance readability with a technical edge. 

- **Manrope** is used for headlines to provide a balanced, professional, and modern feel. 
- **Inter** handles the bulk of the body copy, ensuring maximum legibility at small sizes across financial tables and study guides.
- **Space Grotesk** is utilized for labels, "overlines," and data visualizations to inject a futuristic, science-and-tech aesthetic that aligns with the neon accent. Use all-caps for Space Grotesk labels to emphasize the "technical" nature of the data.

## Layout & Spacing
The system follows a **12-column fluid grid** for web layouts and a **4-column grid** for mobile. A strict 4px/8px baseline grid ensures vertical rhythm.

Layouts should favor generous negative space around primary CTAs to let the neon orange "breathe" without overwhelming the user. Use "Surface Elevated" backgrounds to group related content, creating clear visual containers within the fluid grid.

## Elevation & Depth
Depth is achieved through **Tonal Layering** and **Subtle Glassmorphism**. 

- **Level 0 (Base):** Deep Navy (#0A192F).
- **Level 1 (Cards):** Slate Navy (#112240) with a 1px stroke of #233554 to define edges.
- **Level 2 (Modals/Popovers):** Slate Navy with 80% opacity and a 20px Backdrop Blur to create a frosted glass effect.
- **Shadows:** Use a "Glow" approach for Primary elements. Instead of black shadows, use a highly diffused, low-opacity orange shadow (e.g., #FF6B00 at 20% opacity) for active buttons to make them appear emissive.

## Shapes
The shape language is "Sophisticated Softness." A `rounded-md` (8px) base is used for most components to maintain a modern, friendly feel while still appearing organized and structural. 

- **Buttons:** 8px corner radius.
- **Inputs:** 8px corner radius.
- **Cards:** 16px (rounded-lg) to clearly distinguish content sections.
- **Pills/Tags:** Full-round (pill-shaped) for status indicators and category chips.

## Components
- **Buttons:** Primary buttons use a solid Neon Orange (#FF6B00) fill with Navy (#0A192F) text for maximum contrast. Secondary buttons use a transparent background with a 2px Neon Orange stroke.
- **Chips:** Small, pill-shaped indicators. Use "Deep Navy" backgrounds with "Space Grotesk" text in Neon Orange for high-visibility tagging.
- **Input Fields:** Use a dark, semi-transparent fill. The focus state must trigger a 2px Neon Orange border and a subtle outer glow.
- **Cards:** Use "Surface Elevated" (#112240) with no shadow. Use a top-border accent of 4px Neon Orange for "Featured" or "Active" modules.
- **Progress Bars:** Background track in Deep Navy, with the progress indicator in a linear gradient of Neon Orange to a slightly lighter Tangerine.
- **Interactive Lists:** Hover states should transition the background color of the list item to a slightly lighter Navy (#1D2D50) and change the leading icon to Neon Orange.