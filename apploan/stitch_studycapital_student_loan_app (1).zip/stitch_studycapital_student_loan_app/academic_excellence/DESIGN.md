---
name: Academic Excellence
colors:
  surface: '#f9f9ff'
  surface-dim: '#cfdaf2'
  surface-bright: '#f9f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f0f3ff'
  surface-container: '#e7eeff'
  surface-container-high: '#dee8ff'
  surface-container-highest: '#d8e3fb'
  on-surface: '#111c2d'
  on-surface-variant: '#434653'
  inverse-surface: '#263143'
  inverse-on-surface: '#ecf1ff'
  outline: '#737784'
  outline-variant: '#c3c6d5'
  surface-tint: '#1d59c1'
  primary: '#003c90'
  on-primary: '#ffffff'
  primary-container: '#0f52ba'
  on-primary-container: '#bcceff'
  inverse-primary: '#b0c6ff'
  secondary: '#a7391e'
  on-secondary: '#ffffff'
  secondary-container: '#fd7958'
  on-secondary-container: '#6e1500'
  tertiary: '#32434c'
  on-tertiary: '#ffffff'
  tertiary-container: '#495a64'
  on-tertiary-container: '#bfd1dc'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#d9e2ff'
  primary-fixed-dim: '#b0c6ff'
  on-primary-fixed: '#001945'
  on-primary-fixed-variant: '#00419c'
  secondary-fixed: '#ffdad2'
  secondary-fixed-dim: '#ffb4a2'
  on-secondary-fixed: '#3c0700'
  on-secondary-fixed-variant: '#862208'
  tertiary-fixed: '#d3e5f1'
  tertiary-fixed-dim: '#b7c9d5'
  on-tertiary-fixed: '#0c1e26'
  on-tertiary-fixed-variant: '#384953'
  background: '#f9f9ff'
  on-background: '#111c2d'
  surface-variant: '#d8e3fb'
typography:
  headline-lg:
    fontFamily: Manrope
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Manrope
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.01em
  body-lg:
    fontFamily: Manrope
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Manrope
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-sm:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
    letterSpacing: 0.01em
  button:
    fontFamily: Manrope
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  unit: 4px
  xs: 4px
  sm: 8px
  md: 16px
  lg: 24px
  xl: 32px
  xxl: 48px
  container-margin: 20px
  gutter: 16px
---

## Brand & Style

This design system is built for 'StudyCapital' to bridge the gap between financial institutionalism and student-centric accessibility. The brand personality is optimistic yet grounded, aiming to evoke a sense of clarity and empowerment during the often-stressful process of securing education loans.

The visual direction follows a **Modern Corporate** aesthetic with subtle **Glassmorphism** influences. This approach uses clean layouts and heavy whitespace to ensure legibility, while utilizing soft translucent layers and vibrant background blurs to feel contemporary and tech-forward. It balances the "trust" required for a financial product with the "vibrancy" expected by a younger, digital-native demographic.

## Colors

The palette is anchored by a deep "Trustworthy Blue" as the primary color to establish institutional authority. A "Vibrant Orange" serves as the secondary accent, specifically reserved for primary calls-to-action and motivational highlights to maintain high energy and visibility.

- **Primary (Blue):** Used for navigation, headers, and core brand elements.
- **Secondary (Orange):** Dedicated to conversion points like "Apply Now" or "Submit."
- **Tertiary (Sky):** Used for soft backgrounds, light-tinted cards, and secondary information containers.
- **Surface:** A clean white base with subtle cool-grey neutrals for text and borders to maintain a professional, high-contrast readability.

## Typography

This design system utilizes **Manrope** as the primary typeface for its modern, geometric construction that remains highly legible at various weights. It strikes a balance between professional and friendly. **Inter** is used for smaller labels and utility text to ensure maximum clarity in data-heavy views.

Headlines should use tighter letter spacing and heavier weights to create a strong hierarchy. Body text focuses on generous line heights to facilitate the reading of long-form terms and conditions or application instructions.

## Layout & Spacing

The system employs a **Fluid Grid** model optimized for mobile-first interactions. On mobile devices, a 4-column layout with 20px side margins is standard. For desktop, this scales to a 12-column grid with a maximum container width of 1200px.

Spacing follows a strict 4pt base unit to ensure rhythmic consistency. Vertical rhythm is established through `xxl` spacing between major sections and `md` spacing between related elements within a card or group. Large margins are encouraged to prevent the interface from feeling "crowded," reinforcing a sense of financial transparency.

## Elevation & Depth

Visual hierarchy is achieved through a combination of **Tonal Layers** and **Ambient Shadows**. 

1.  **Base Layer:** Solid white or very light grey (#F8FAFC) background.
2.  **Raised Layer (Cards):** Pure white surfaces with a soft, diffused shadow (0px 4px 20px rgba(15, 82, 186, 0.08)). The shadow is slightly tinted with the primary blue to maintain color harmony.
3.  **Overlay Layer (Modals/Drawers):** Uses a backdrop blur (12px) to focus the student's attention on specific tasks while maintaining the context of the application in the background.
4.  **Glass Elements:** Small utility chips or informational banners use a 60% opacity fill with a 1px white border to simulate depth without heavy shadowing.

## Shapes

The shape language is defined by a "Rounded" (Level 2) logic. This softens the formal nature of a loan app, making it more approachable for students. 

- **Standard Buttons & Inputs:** 0.5rem (8px) corner radius.
- **Content Cards:** 1rem (16px) corner radius.
- **Bottom Sheets & Modals:** 1.5rem (24px) top-corner radius for a modern "app-like" feel.
- **Icon Containers:** Circular or highly rounded "squircle" shapes to reference the brand's friendly tech aesthetic.

## Components

### Buttons
- **Primary:** Solid "Vibrant Orange" background with white text. High-contrast and slightly larger padding (16px top/bottom).
- **Secondary:** Outlined with "Primary Blue" border and text. Used for "Back" or "Save for Later" actions.

### Input Fields
Inputs use a light grey border that transitions to the "Primary Blue" when focused. They include clear, floating labels and support for prepended icons (e.g., currency symbols or country codes).

### Cards
Cards are the primary structural element. They should have a 1px soft border (#E2E8F0) and an ambient shadow. Section headers within cards use `headline-md` for clear separation of loan details.

### Progress Indicators
Essential for the multi-step loan application. Use a "Stepper" component at the top of the screen with the "Primary Blue" for completed steps and a soft sky-blue for remaining steps.

### Chips/Badges
Used for loan status (e.g., "Approved", "Pending"). Status chips should use highly desaturated versions of semantic colors (Green for success, Blue for info, Orange for warning) with high-contrast text.